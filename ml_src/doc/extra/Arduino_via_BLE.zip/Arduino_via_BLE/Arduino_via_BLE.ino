#include <ArduinoBLE.h>

String BLE_NAME = "MyBLEDevice001";

unsigned pinout[] = { D2, D3, D4, D5, D6, D7, D8, D9, D10, D11, D12 };
unsigned ledout[] = { LEDR, LEDG, LEDB };
const unsigned nchan = sizeof(pinout) / sizeof(unsigned);  // number of reward channels
const unsigned nled = sizeof(ledout) / sizeof(unsigned);

const char* myServiceUuid = "01951185-e572-7a1f-86b6-a20018e7dbf2";
const char* myServiceCharacteristicUuid = "01951186-e572-7a1f-86b6-a20018e7dbf2";
BLEService myService(myServiceUuid); 
BLEStringCharacteristic myCharacteristic(myServiceCharacteristicUuid, BLERead | BLEWrite, 30);

void setup()
{
  // init Serial
  Serial.begin(9600);
  for (unsigned m=0; m<3; m++)
  {
    if (Serial)
    {
      Serial.println("Serial data transmission started! " + String(m));
      break;
    }
    delay(1000);
  }
 
  // init output pins & LEDs
  for (unsigned m=0; m<nchan; m++)
  {
    pinMode(pinout[m], OUTPUT);
    digitalWrite(pinout[m], LOW);
  }
  pinMode(LED_BUILTIN, OUTPUT);     // This is also D13
  digitalWrite(LED_BUILTIN, LOW);
  for (unsigned m=0; m<nled; m++)
  {
    pinMode(ledout[m], OUTPUT);
    digitalWrite(ledout[m], HIGH);  // LEDs are off at HIGH
  }
  
  // test BLE
  if (!BLE.begin())
  {
    if (Serial) Serial.println("Bluetooth® Low Energy module failed!");
    while (1)
    {
      digitalWrite(LEDR, LOW);
      delay(100);
      digitalWrite(LEDR, HIGH);
      delay(100);
    }
  }
  if (Serial) Serial.println("Bluetooth® Low Energy module started!");

  // init BLE
  BLE.setLocalName(BLE_NAME.c_str());
  myCharacteristic.writeValue("");
  myService.addCharacteristic(myCharacteristic);
  BLE.addService(myService);
  BLE.setAdvertisedService(myService);
  BLE.advertise();

  // display this (peripheral) device name
  if (Serial)
  {
    Serial.println("* Name of this (peripheral) device: " + BLE_NAME);
    Serial.println(" ");
  }
}

unsigned search_time = 0;

void loop()
{
  // search central device
  BLEDevice central = BLE.central();
  if (Serial) Serial.println("Discovering central device..." + String(search_time));

  // blink red
  digitalWrite(LEDG, bitRead(search_time,0));
  delay(1000);
  search_time += 1;  
  
  if (central)
  {
    if (Serial)
    {
      Serial.println("* Connected to central device!");
      Serial.print("* Device MAC address: ");
      Serial.println(central.address());
      Serial.println(" ");
    }
    digitalWrite(LEDG, HIGH);
    digitalWrite(LEDB, LOW);

    bool reset = false;
    while (central.connected() && !reset)
    {
      if (myCharacteristic.written())
      {
        String cmd = myCharacteristic.value();
        cmd.trim();
        if (0==cmd.length()) continue;
        if (Serial) Serial.println(cmd);

        String result = "P1";  // Command not understood
        switch (cmd.charAt(0))
        {
          case 'Q':  // query current state
            result = "READY";
            break;
          
          case 'R':  // reset
            reset = true;
            result = "OK";
            break;

          case 'Y': {  // deliver reward, Y<juice line>,<duration>,<num reward>,<pause time>
            long comma1 = cmd.indexOf(',',1);
            long comma2 = cmd.indexOf(',',comma1+1);
            long comma3 = cmd.indexOf(',',comma2+1);
            if (comma1<1 || comma2<1 | comma3<1)
            {
              result = "P3";  // Parameter error
              break;
            }

            unsigned juiceline = cmd.substring(1,comma1).toInt() - 1;  // 0-based
            unsigned duration = cmd.substring(comma1+1,comma2).toInt();
            unsigned numreward = cmd.substring(comma2+1,comma3).toInt();
            unsigned pausetime = cmd.substring(comma3+1).toInt();
            if (nchan<=juiceline)
            {
              result = "P2";  // Solenoid does not exist
              break;
            }

            for (unsigned m=1; m<=numreward; m++)
            {
              digitalWrite(LED_BUILTIN, HIGH);
              digitalWrite(pinout[juiceline], HIGH);
              delay(duration);
              digitalWrite(pinout[juiceline], LOW);
              digitalWrite(LED_BUILTIN, LOW);
              if (m<numreward) delay(pausetime);
            }
            result = "OK";
            break;
          }
        }

        myCharacteristic.writeValue(result);
        if (Serial) Serial.println((result + '\n').c_str());
      }
    }
    
    if (Serial) Serial.println("Disconnected from central device!");
    digitalWrite(LEDB, HIGH);
    search_time = 0;
  }
}